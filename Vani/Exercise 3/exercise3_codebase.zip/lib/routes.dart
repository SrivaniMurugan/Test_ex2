// TODO  Define the class "Routes". It should contain:
// - constant strings that indicates the names of the routes
// - a method that generate all routes

import 'package:flutter/material.dart';

class Routes {
  static Route<dynamic> createRoute(settings) {
    return null;
  }
}
