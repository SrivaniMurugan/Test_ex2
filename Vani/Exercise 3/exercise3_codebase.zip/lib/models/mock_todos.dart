// TODO  Create some mock data about todo list as well as mock data of task list for each todo item.

import 'todo.dart';
// import 'task.dart';

final myTodoList = <Todo>[];
