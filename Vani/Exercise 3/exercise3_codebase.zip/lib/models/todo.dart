// TODO Define the model class Todo here. The attributes are given. Complete the rest.

// import 'task.dart';

class Todo {}
